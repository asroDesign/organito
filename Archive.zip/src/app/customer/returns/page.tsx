import {requirePage} from '@/lib/auth';
import {PageHeader} from '@/components/ui';
import {ReturnsManager} from '@/components/CommerceClient';
export default async function Page(){await requirePage({role:'customer'});return <><PageHeader title="درخواست‌های مرجوعی"/><ReturnsManager area="customer"/></>}
